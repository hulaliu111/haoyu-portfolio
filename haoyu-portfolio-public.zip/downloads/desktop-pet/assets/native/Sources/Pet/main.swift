import AppKit

// MARK: - 寻找素材目录（兼容打包成 .app 和直接运行）
func assetDirURL(_ relativeDir: String) -> URL? {
    if let resources = Bundle.main.resourceURL {
        let candidate = resources.appendingPathComponent(relativeDir)
        if FileManager.default.fileExists(atPath: candidate.path) {
            return candidate
        }
    }
    let cwd = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let cwdCandidate = cwd.appendingPathComponent(relativeDir)
    if FileManager.default.fileExists(atPath: cwdCandidate.path) {
        return cwdCandidate
    }
    let execDir = URL(fileURLWithPath: CommandLine.arguments[0]).deletingLastPathComponent()
    let execCandidate = execDir.appendingPathComponent(relativeDir)
    if FileManager.default.fileExists(atPath: execCandidate.path) {
        return execCandidate
    }
    return nil
}

func loadFrames(_ dir: String, _ names: [String]) -> [NSImage] {
    guard let d = assetDirURL(dir) else { return [] }
    return names.compactMap { name in
        NSImage(contentsOfFile: d.appendingPathComponent("\(name).png").path)
    }
}

// 水平镜像一张图片（往左走时让角色朝左）
func horizontallyFlipped(_ image: NSImage) -> NSImage {
    let size = image.size
    return NSImage(size: size, flipped: false) { rect in
        let transform = NSAffineTransform()
        transform.translateX(by: rect.width, yBy: 0)
        transform.scaleX(by: -1, yBy: 1)
        transform.concat()
        image.draw(in: rect)
        return true
    }
}

// MARK: - 加载动作帧
// 小恐龙：待机 + 走路（会自动走动）
let dinoIdle = loadFrames("新切图素材/待机", ["scratch_01", "scratch_02", "scratch_03", "scratch_04"])
let dinoWalk = loadFrames("新切图素材/走路", ["walk_01", "walk_02", "walk_03", "walk_04"])
guard let dinoFirst = dinoIdle.first, !dinoWalk.isEmpty else {
    print("找不到小恐龙动作帧（新切图素材/待机、走路）")
    exit(1)
}
let dinoWalkRight = dinoWalk
let dinoWalkLeft = dinoWalk.map { horizontallyFlipped($0) }

// 猫咪：待机动作（原地循环，先不自动走动）
let catIdle = loadFrames("新切图素材/猫咪/待机", ["scratch_01", "scratch_02", "scratch_03", "scratch_04"])
guard let catFirst = catIdle.first else {
    print("找不到猫咪动作帧（新切图素材/猫咪/待机/scratch_0X.png）")
    exit(1)
}
let catWalkRight = catIdle
let catWalkLeft = catIdle

// MARK: - 可拖拽的图片视图
// 基于图片“不透明像素”做身体判定：透明处让窗口忽略鼠标（穿透到桌面），身体处可拖动。
final class DraggableImageView: NSImageView {
    private(set) var isDragging = false
    var onDragEnd: (() -> Void)?
    var onDoubleClick: (() -> Void)?

    private var bodyMask: [Bool] = []
    private var maskWidth = 0
    private var maskHeight = 0
    private var dragStartWindowOrigin: NSPoint = .zero
    private var dragStartMouseScreen: NSPoint = .zero

    func setBodyMask(_ rep: NSBitmapImageRep) {
        maskWidth = rep.pixelsWide
        maskHeight = rep.pixelsHigh
        var mask = [Bool](repeating: false, count: maskWidth * maskHeight)
        for y in 0..<maskHeight {
            for x in 0..<maskWidth {
                if let color = rep.colorAt(x: x, y: y), color.alphaComponent > 0.1 {
                    mask[y * maskWidth + x] = true
                }
            }
        }
        bodyMask = mask
    }

    // 判断某个屏幕坐标是否落在“身体”上（不透明像素）
    func isBodyPoint(screenPoint: NSPoint) -> Bool {
        guard let win = window else { return false }
        let windowPoint = win.convertPoint(fromScreen: screenPoint)
        return isBodyWindowPoint(windowPoint)
    }

    private func isBodyWindowPoint(_ point: NSPoint) -> Bool {
        guard maskWidth > 0, maskHeight > 0, bounds.width > 0, bounds.height > 0 else { return false }
        let fx = point.x / bounds.width
        let fy = point.y / bounds.height
        guard fx >= 0, fx <= 1, fy >= 0, fy <= 1 else { return false }
        let px = Int(fx * CGFloat(maskWidth - 1))
        // colorAt 的 y=0 在顶部；view 坐标 y 自下而上，所以取反
        let py = Int((1 - fy) * CGFloat(maskHeight - 1))
        let index = py * maskWidth + px
        guard index >= 0, index < bodyMask.count else { return false }
        return bodyMask[index]
    }

    override func mouseDown(with event: NSEvent) {
        if event.clickCount == 2 {
            onDoubleClick?()
            return
        }
        isDragging = true
        dragStartMouseScreen = NSEvent.mouseLocation
        dragStartWindowOrigin = window!.frame.origin
    }

    override func mouseDragged(with event: NSEvent) {
        guard let win = window, isDragging else { return }
        let current = NSEvent.mouseLocation
        var frame = win.frame
        frame.origin = NSPoint(
            x: dragStartWindowOrigin.x + (current.x - dragStartMouseScreen.x),
            y: dragStartWindowOrigin.y + (current.y - dragStartMouseScreen.y)
        )
        win.setFrame(frame, display: true)
    }

    override func mouseUp(with event: NSEvent) {
        isDragging = false
        onDragEnd?()
    }
}

// MARK: - App
let app = NSApplication.shared
app.setActivationPolicy(.accessory)

// MARK: - 行为状态机：待机 → 随机走 → 停顿 → 走回起点 → 待机
final class PetBehavior {
    private let window: NSWindow
    private let imageView: DraggableImageView
    private let idleFrames: [NSImage]
    private let walkRightFrames: [NSImage]
    private let walkLeftFrames: [NSImage]
    private var homeOrigin: NSPoint

    private enum State { case idle, walkAway, pause, walkBack }
    private var state: State = .idle

    private let tickInterval: TimeInterval = 0.05
    private let idleTicksPerFrame = 5   // 0.25s / 帧
    private let walkTicksPerFrame = 3   // 0.15s / 帧
    private let moveStep: CGFloat = 1.6 // 每帧像素，约 32 像素/秒

    private var timer: Timer?
    private var idleFrameIndex = 0
    private var walkFrameIndex = 0
    private var ticksInCurrentFrame = 0
    private var idleSecondsRemaining: TimeInterval = 0
    private var walkTargetX: CGFloat = 0
    private var turnPauseRemaining: TimeInterval = 0

    // 测试用
    private let debugURL: URL?
    private let firstWalkAfter: TimeInterval?
    private let walkDistOverride: CGFloat?
    private var hasWalkedOnce = false
    private(set) var isPaused = false
    private let disableWalk: Bool

    init(window: NSWindow, imageView: DraggableImageView, idleFrames: [NSImage],
         walkRightFrames: [NSImage], walkLeftFrames: [NSImage], homeOrigin: NSPoint,
         disableWalk: Bool = false) {
        self.window = window
        self.imageView = imageView
        self.idleFrames = idleFrames
        self.walkRightFrames = walkRightFrames
        self.walkLeftFrames = walkLeftFrames
        self.homeOrigin = homeOrigin
        self.disableWalk = disableWalk
        let env = ProcessInfo.processInfo.environment
        self.debugURL = env["PET_DEBUG_LOG"].map { URL(fileURLWithPath: $0) }
        self.firstWalkAfter = env["PET_FIRST_WALK_AFTER"].flatMap(Double.init)
        self.walkDistOverride = env["PET_WALK_DIST"].flatMap(Double.init).map { CGFloat($0) }
    }

    func start() {
        idleSecondsRemaining = nextIdleDelay()
        timer = Timer.scheduledTimer(withTimeInterval: tickInterval, repeats: true) { [weak self] _ in
            self?.tick()
        }
        RunLoop.main.add(timer!, forMode: .common)
        log("start idle")
    }

    // 拖动结束后调用：把当前位置设为新的“家”，恢复待机
    func handleDropped() {
        homeOrigin = window.frame.origin
        state = .idle
        idleFrameIndex = 0
        ticksInCurrentFrame = idleTicksPerFrame
        idleSecondsRemaining = nextIdleDelay()
        imageView.image = idleFrames[idleFrameIndex]
        log("dropped at \(homeOrigin)")
    }

    func togglePause() {
        isPaused.toggle()
        log("paused=\(isPaused)")
    }

    private func nextIdleDelay() -> TimeInterval {
        if !hasWalkedOnce, let override = firstWalkAfter {
            hasWalkedOnce = true
            return override
        }
        return TimeInterval.random(in: 3.5...7.5)
    }

    private func tick() {
        // 鼠标穿透：拖动时强制接收鼠标，否则按“是否落在身体上”切换
        if imageView.isDragging {
            window.ignoresMouseEvents = false
            return // 拖动时暂停自动移动
        } else {
            window.ignoresMouseEvents = !imageView.isBodyPoint(screenPoint: NSEvent.mouseLocation)
        }

        // 暂停时只更新鼠标穿透，不做动画/移动
        if isPaused { return }

        switch state {
        case .idle: tickIdle()
        case .walkAway, .walkBack: tickWalk()
        case .pause: tickPause()
        }
    }

    private func tickIdle() {
        ticksInCurrentFrame += 1
        if ticksInCurrentFrame >= idleTicksPerFrame {
            ticksInCurrentFrame = 0
            idleFrameIndex = (idleFrameIndex + 1) % idleFrames.count
            imageView.image = idleFrames[idleFrameIndex]
        }
        idleSecondsRemaining -= tickInterval
        if idleSecondsRemaining <= 0 {
            if disableWalk {
                idleSecondsRemaining = .greatestFiniteMagnitude
            } else {
                beginWalk()
            }
        }
    }

    private func beginWalk() {
        guard let visible = (window.screen ?? NSScreen.main)?.visibleFrame else {
            idleSecondsRemaining = nextIdleDelay()
            return
        }
        let minX = visible.minX
        let maxX = visible.maxX - window.frame.width
        let startX = homeOrigin.x

        var direction: CGFloat = Bool.random() ? 1 : -1
        var space = direction > 0 ? (maxX - startX) : (startX - minX)
        if space < 60 {
            direction = -direction
            space = direction > 0 ? (maxX - startX) : (startX - minX)
        }
        if space < 60 {
            idleSecondsRemaining = nextIdleDelay()
            return
        }

        let requested = walkDistOverride ?? CGFloat.random(in: 120...220)
        let distance = min(requested, space)
        walkTargetX = startX + direction * distance
        state = .walkAway
        walkFrameIndex = 0
        ticksInCurrentFrame = walkTicksPerFrame
        log("beginWalk dir=\(direction) dist=\(distance) toX=\(walkTargetX)")
    }

    private func tickWalk() {
        ticksInCurrentFrame += 1
        if ticksInCurrentFrame >= walkTicksPerFrame {
            ticksInCurrentFrame = 0
            walkFrameIndex = (walkFrameIndex + 1) % walkFramesCount
            imageView.image = currentWalkFrame()
        }

        var frame = window.frame
        let targetX = state == .walkAway ? walkTargetX : homeOrigin.x
        let remaining = targetX - frame.origin.x

        if abs(remaining) <= moveStep {
            frame.origin.x = targetX
            window.setFrame(frame, display: true)
            if state == .walkAway {
                state = .pause
                turnPauseRemaining = 0.45
                log("reached far x=\(frame.origin.x)")
            } else {
                state = .idle
                idleFrameIndex = 0
                ticksInCurrentFrame = idleTicksPerFrame
                idleSecondsRemaining = nextIdleDelay()
                imageView.image = idleFrames[idleFrameIndex]
                log("back home x=\(frame.origin.x)")
            }
        } else {
            let sign: CGFloat = remaining > 0 ? 1 : -1
            frame.origin.x += sign * moveStep
            window.setFrame(frame, display: true)
        }
    }

    private func tickPause() {
        turnPauseRemaining -= tickInterval
        if turnPauseRemaining <= 0 {
            state = .walkBack
            walkFrameIndex = 0
            ticksInCurrentFrame = walkTicksPerFrame
            log("start walk back")
        }
    }

    private var walkFramesCount: Int { max(walkLeftFrames.count, walkRightFrames.count) }

    private func currentWalkFrame() -> NSImage {
        let targetX = state == .walkAway ? walkTargetX : homeOrigin.x
        let movingRight = targetX >= window.frame.origin.x
        let frames = movingRight ? walkRightFrames : walkLeftFrames
        let index = min(walkFrameIndex, frames.count - 1)
        return frames[index]
    }

    private func log(_ message: String) {
        guard let url = debugURL else { return }
        let line = "[\(Date())] \(message) x=\(window.frame.origin.x) state=\(state)\n"
        let data = line.data(using: .utf8)!
        if let handle = try? FileHandle(forWritingTo: url) {
            handle.seekToEndOfFile()
            handle.write(data)
            try? handle.close()
        } else {
            try? line.write(to: url, atomically: true, encoding: .utf8)
        }
    }
}

// MARK: - 聊天窗口
// 让内容自上而下排列的视图，用于消息区按顺序排布
final class FlippedView: NSView {
    override var isFlipped: Bool { true }
}

// MARK: - AI 配置（保存在 ~/.desktop-pet/config.json，在仓库之外，不会提交到 Git）
struct AIConfig: Codable {
    var apiKey: String
    var model: String
    var baseURL: String
}

enum ConfigStore {
    static var configURL: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent(".desktop-pet/config.json")
    }

    // 首次运行生成默认配置模板
    static func ensureExists() {
        let fm = FileManager.default
        guard !fm.fileExists(atPath: configURL.path) else { return }
        try? fm.createDirectory(
            at: configURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        let defaults = AIConfig(
            apiKey: "",
            model: "deepseek-chat",
            baseURL: "https://api.deepseek.com"
        )
        if let data = try? JSONEncoder().encode(defaults) {
            try? data.write(to: configURL)
        }
    }

    static func load() -> AIConfig? {
        guard let data = try? Data(contentsOf: configURL) else { return nil }
        return try? JSONDecoder().decode(AIConfig.self, from: data)
    }

    static func save(_ config: AIConfig) {
        let fm = FileManager.default
        try? fm.createDirectory(
            at: configURL.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        if let data = try? JSONEncoder().encode(config) {
            try? data.write(to: configURL)
        }
    }
}

// MARK: - DeepSeek 客户端（OpenAI 兼容接口）
final class DeepSeekClient {
    private let baseURL: String
    private let apiKey: String
    private let model: String

    init(config: AIConfig) {
        self.baseURL = config.baseURL
        self.apiKey = config.apiKey
        self.model = config.model
    }

    func chat(_ userMessage: String) async throws -> String {
        var components = URLComponents(string: baseURL)
        guard components?.scheme != nil, components?.host != nil else {
            throw NSError(domain: "DeepSeek", code: -1, userInfo: [NSLocalizedDescriptionKey: "接口地址配置有误"])
        }
        // 兼容带或不带 /v1 的地址
        var path = components?.path ?? ""
        if !path.hasSuffix("/chat/completions") {
            if !path.hasSuffix("/") { path += "/" }
            path += "chat/completions"
        }
        components?.path = path
        guard let url = components?.url else {
            throw NSError(domain: "DeepSeek", code: -1, userInfo: [NSLocalizedDescriptionKey: "接口地址配置有误"])
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 30
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let body: [String: Any] = [
            "model": model,
            "messages": [
                ["role": "system", "content": "你是桌面小恐龙，说话语气可爱、亲切，回复尽量简短。"],
                ["role": "user", "content": userMessage]
            ],
            "stream": false
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            let message = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "DeepSeek", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: message])
        }

        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let choices = json?["choices"] as? [[String: Any]]
        let content = choices?.first?["message"] as? [String: Any]
        let reply = content?["content"] as? String
        return reply?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }
}

// MARK: - 单条消息行（用于打字机逐字更新）
final class MessageRow {
    let container: NSView
    let bubble: NSView
    let label: NSTextField
    let isUser: Bool
    var currentText: String
    var height: CGFloat

    init(container: NSView, bubble: NSView, label: NSTextField, isUser: Bool, currentText: String, height: CGFloat) {
        self.container = container
        self.bubble = bubble
        self.label = label
        self.isUser = isUser
        self.currentText = currentText
        self.height = height
    }
}

final class ChatWindowController: NSObject {
    private let window: NSWindow
    private let scrollView: NSScrollView
    private let messageContainer: FlippedView
    private let inputField: NSTextField
    private let contentWidth: CGFloat = 340
    private let inputHeight: CGFloat = 46
    private var documentHeight: CGFloat = 0
    private var rows: [MessageRow] = []
    private let textPadding: CGFloat = 12
    private let margin: CGFloat = 12

    override init() {
        let contentSize = NSSize(width: contentWidth, height: 480)

        // 第一段：只给存储属性赋值，这段还不能用 self
        window = NSWindow(
            contentRect: NSRect(origin: .zero, size: contentSize),
            styleMask: [.titled, .closable, .miniaturizable],
            backing: .buffered,
            defer: false
        )
        let scrollFrame = NSRect(x: 0, y: inputHeight, width: contentWidth, height: contentSize.height - inputHeight)
        scrollView = NSScrollView(frame: scrollFrame)
        messageContainer = FlippedView(
            frame: NSRect(origin: .zero, size: NSSize(width: contentWidth, height: 0))
        )
        inputField = NSTextField(
            frame: NSRect(x: 12, y: 9, width: contentWidth - 72, height: 28)
        )

        super.init()

        // 第二段：父类初始化完成，可以安全使用 self
        window.title = "和芋圆聊天"
        window.isReleasedWhenClosed = false
        window.center()

        scrollView.hasVerticalScroller = true
        scrollView.autohidesScrollers = true
        scrollView.drawsBackground = false
        scrollView.documentView = messageContainer

        inputField.placeholderString = "说点什么…"
        inputField.bezelStyle = .roundedBezel
        inputField.font = .systemFont(ofSize: 14)
        inputField.target = self
        inputField.action = #selector(sendMessage(_:))

        let inputBar = NSView(frame: NSRect(x: 0, y: 0, width: contentWidth, height: inputHeight))
        inputBar.addSubview(inputField)

        let sendButton = NSButton(title: "发送", target: self, action: #selector(sendMessage(_:)))
        sendButton.frame = NSRect(x: contentWidth - 54, y: 9, width: 42, height: 28)
        sendButton.bezelStyle = .rounded
        inputBar.addSubview(sendButton)

        // 装到窗口
        let container = NSView(frame: NSRect(origin: .zero, size: contentSize))
        container.addSubview(scrollView)
        container.addSubview(inputBar)
        window.contentView = container
    }

    func show() {
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    // 调试：填充示例消息
    func seedDebugMessages() {
        appendMessage("你好呀", fromUser: true)
        appendMessage("我收到啦", fromUser: false)
        appendMessage("今天过得怎么样？", fromUser: true)
        appendMessage("我收到啦", fromUser: false)
    }

    // 调试：把窗口内容导出成图片
    func captureTo(_ path: String) {
        guard let content = window.contentView,
              let rep = content.bitmapImageRepForCachingDisplay(in: content.bounds) else { return }
        content.cacheDisplay(in: content.bounds, to: rep)
        if let data = rep.representation(using: .png, properties: [:]) {
            try? data.write(to: URL(fileURLWithPath: path))
        }
    }

    @objc private func sendMessage(_ sender: Any?) {
        let text = inputField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        inputField.stringValue = ""
        appendMessage(text, fromUser: true)

        // 未配置 apiKey 时提示先去配置
        guard let config = ConfigStore.load(), !config.apiKey.isEmpty else {
            let path = ConfigStore.configURL.path
            appendMessage(
                "请先配置 AI：打开 \(path)，把 apiKey 填上（模型默认 deepseek-chat，接口默认 https://api.deepseek.com）。配置好再问我吧～",
                fromUser: false
            )
            return
        }

        let client = DeepSeekClient(config: config)
        let placeholder = appendMessage("正在输入…", fromUser: false)
        let placeholderIndex = rows.count - 1

        Task {
            do {
                let reply = try await client.chat(text)
                let finalText = reply.isEmpty ? "……" : reply
                DispatchQueue.main.async { [weak self] in
                    guard let self = self, self.rows.indices.contains(placeholderIndex) else { return }
                    self.animateTyping(finalText, into: self.rows[placeholderIndex])
                }
            } catch {
                let detail = (error as NSError).localizedDescription
                DispatchQueue.main.async { [weak self] in
                    guard let self = self, self.rows.indices.contains(placeholderIndex) else { return }
                    self.updateTypingRow(self.rows[placeholderIndex], "请求失败：\(detail)")
                }
            }
        }
    }

    @discardableResult
    private func appendMessage(_ text: String, fromUser: Bool) -> MessageRow {
        let m = measurements(for: text)
        let rowHeight = m.bubbleSize.height + 8
        let row = NSView(frame: NSRect(x: 0, y: documentHeight, width: contentWidth, height: rowHeight))
        let bubble = NSView(
            frame: NSRect(
                x: fromUser ? contentWidth - m.bubbleSize.width - margin : margin,
                y: 4,
                width: m.bubbleSize.width,
                height: m.bubbleSize.height
            )
        )
        bubble.wantsLayer = true
        let isDark = bubble.effectiveAppearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
        let fill = fromUser ? NSColor.systemBlue : (isDark ? NSColor(white: 0.32, alpha: 1) : NSColor(white: 0.92, alpha: 1))
        bubble.layer?.backgroundColor = fill.cgColor
        bubble.layer?.cornerRadius = 14

        let label = NSTextField(labelWithString: text)
        label.font = NSFont.systemFont(ofSize: 14)
        label.textColor = fromUser ? .white : .labelColor
        label.lineBreakMode = .byWordWrapping
        label.usesSingleLineMode = false
        label.maximumNumberOfLines = 0
        label.frame = NSRect(
            x: textPadding,
            y: textPadding,
            width: m.labelWidth,
            height: m.bubbleSize.height - textPadding * 2
        )
        bubble.addSubview(label)
        row.addSubview(bubble)
        messageContainer.addSubview(row)

        let model = MessageRow(
            container: row,
            bubble: bubble,
            label: label,
            isUser: fromUser,
            currentText: text,
            height: rowHeight
        )
        rows.append(model)
        layoutRows()
        return model
    }

    private func measurements(for text: String) -> (bubbleSize: NSSize, labelWidth: CGFloat) {
        let maxBubbleWidth = contentWidth - 110
        let font = NSFont.systemFont(ofSize: 14)
        let bounding = (text as NSString).boundingRect(
            with: NSSize(width: maxBubbleWidth - textPadding * 2, height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            attributes: [.font: font]
        )
        let labelWidth = ceil(bounding.width) + 6
        let bubbleWidth = min(maxBubbleWidth, labelWidth + textPadding * 2)
        let actualLabelWidth = bubbleWidth - textPadding * 2
        let bubbleSize = NSSize(width: bubbleWidth, height: ceil(bounding.height) + textPadding * 2)
        return (bubbleSize, actualLabelWidth)
    }

    private func layoutRows() {
        var y: CGFloat = 0
        for row in rows {
            row.container.frame = NSRect(x: 0, y: y, width: contentWidth, height: row.height)
            y += row.height
        }
        documentHeight = y
        messageContainer.frame.size.height = documentHeight
        let clipHeight = scrollView.contentView.bounds.height
        let scrollY = max(0, documentHeight - clipHeight)
        scrollView.contentView.scroll(to: NSPoint(x: 0, y: scrollY))
        scrollView.reflectScrolledClipView(scrollView.contentView)
    }

    // 更新一条消息的文本并重排（打字机效果用）
    private func updateTypingRow(_ row: MessageRow, _ text: String) {
        row.currentText = text
        let m = measurements(for: text)
        row.height = m.bubbleSize.height + 8
        row.bubble.frame = NSRect(
            x: row.isUser ? contentWidth - m.bubbleSize.width - margin : margin,
            y: 4,
            width: m.bubbleSize.width,
            height: m.bubbleSize.height
        )
        row.label.stringValue = text
        row.label.frame = NSRect(
            x: textPadding,
            y: textPadding,
            width: m.labelWidth,
            height: m.bubbleSize.height - textPadding * 2
        )
        layoutRows()
    }

    // 打字机效果：逐个字符显示
    private func animateTyping(_ fullText: String, into row: MessageRow) {
        var index = 1
        let timer = Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { [weak self] timer in
            guard let self = self else { timer.invalidate(); return }
            let partial = String(fullText.prefix(index))
            self.updateTypingRow(row, partial)
            if index >= fullText.count {
                timer.invalidate()
            }
            index += 1
        }
        RunLoop.main.add(timer, forMode: .common)
    }

    // 调试：模拟发送一条消息
    func debugAutoSend(_ text: String) {
        inputField.stringValue = text
        sendMessage(nil)
    }

    // 自动发送一条消息给 AI（用于双击触发对话）
    func autoSend(_ text: String) {
        inputField.stringValue = text
        sendMessage(nil)
    }
}

// MARK: - 设置面板
final class SettingsWindowController: NSObject {
    private let window: NSWindow
    private let modelPopup: NSPopUpButton
    private let secureField: NSSecureTextField
    private let visibleField: NSTextField
    private let urlField: NSTextField
    private let statusLabel: NSTextField
    private var isKeyVisible = false

    private static let models = ["deepseek-chat", "deepseek-reasoner"]

    override init() {
        let panelWidth: CGFloat = 380
        let panelHeight: CGFloat = 300

        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: panelWidth, height: panelHeight),
            styleMask: [.titled, .closable],
            backing: .buffered,
            defer: false
        )
        modelPopup = NSPopUpButton(frame: .zero, pullsDown: false)
        secureField = NSSecureTextField(frame: .zero)
        visibleField = NSTextField(frame: .zero)
        urlField = NSTextField(frame: .zero)
        statusLabel = NSTextField(labelWithString: "")

        super.init()

        window.title = "设置"
        window.isReleasedWhenClosed = false
        window.center()

        let content = FlippedView(frame: NSRect(x: 0, y: 0, width: panelWidth, height: panelHeight))
        let padding: CGFloat = 20
        let fieldWidth = panelWidth - padding * 2
        var y: CGFloat = 20

        func label(_ text: String) {
            let l = NSTextField(labelWithString: text)
            l.font = .systemFont(ofSize: 13, weight: .medium)
            l.textColor = .secondaryLabelColor
            l.frame = NSRect(x: padding, y: y, width: fieldWidth, height: 16)
            content.addSubview(l)
            y += 16 + 6
        }

        // 模型
        label("模型")
        modelPopup.frame = NSRect(x: padding, y: y, width: fieldWidth, height: 28)
        modelPopup.addItems(withTitles: SettingsWindowController.models)
        content.addSubview(modelPopup)
        y += 28 + 14

        // API Key
        label("API Key")
        let eyeWidth: CGFloat = 26
        let keyFrame = NSRect(x: padding, y: y, width: fieldWidth - eyeWidth - 8, height: 28)
        secureField.frame = keyFrame
        secureField.placeholderString = "sk-..."
        secureField.bezelStyle = .roundedBezel
        secureField.font = .systemFont(ofSize: 14)
        content.addSubview(secureField)

        visibleField.frame = keyFrame
        visibleField.placeholderString = "sk-..."
        visibleField.bezelStyle = .roundedBezel
        visibleField.font = .systemFont(ofSize: 14)
        visibleField.isHidden = true
        content.addSubview(visibleField)

        let eyeButton = NSButton(frame: NSRect(x: panelWidth - padding - eyeWidth, y: y, width: eyeWidth, height: 28))
        eyeButton.isBordered = false
        eyeButton.imagePosition = .imageOnly
        eyeButton.contentTintColor = .labelColor
        eyeButton.target = self
        eyeButton.action = #selector(toggleKeyVisibility(_:))
        if let eye = NSImage(systemSymbolName: "eye", accessibilityDescription: "显示 Key") {
            eyeButton.image = eye
        }
        content.addSubview(eyeButton)
        y += 28 + 14

        // 接口地址
        label("接口地址")
        urlField.frame = NSRect(x: padding, y: y, width: fieldWidth, height: 28)
        urlField.placeholderString = "https://api.deepseek.com"
        urlField.font = .systemFont(ofSize: 14)
        content.addSubview(urlField)
        y += 28 + 14

        // 状态提示
        statusLabel.frame = NSRect(x: padding, y: y, width: fieldWidth, height: 16)
        statusLabel.font = .systemFont(ofSize: 12)
        statusLabel.textColor = .secondaryLabelColor
        statusLabel.stringValue = " "
        content.addSubview(statusLabel)
        y += 16 + 6

        // 按钮
        let btnWidth: CGFloat = 96
        let testButton = NSButton(title: "测试连接", target: self, action: #selector(testConnection(_:)))
        testButton.frame = NSRect(x: padding, y: y, width: btnWidth, height: 30)
        testButton.bezelStyle = .rounded
        content.addSubview(testButton)

        let saveButton = NSButton(title: "保存", target: self, action: #selector(save(_:)))
        saveButton.frame = NSRect(x: panelWidth - padding - btnWidth, y: y, width: btnWidth, height: 30)
        saveButton.bezelStyle = .rounded
        saveButton.bezelColor = .controlAccentColor
        saveButton.contentTintColor = .white
        content.addSubview(saveButton)
        y += 30

        window.contentView = content
    }

    func show() {
        loadConfig()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    private func loadConfig() {
        guard let config = ConfigStore.load() else { return }
        secureField.stringValue = config.apiKey
        visibleField.stringValue = config.apiKey
        urlField.stringValue = config.baseURL
        if let index = SettingsWindowController.models.firstIndex(of: config.model) {
            modelPopup.selectItem(at: index)
        } else {
            modelPopup.addItem(withTitle: config.model)
            modelPopup.selectItem(at: modelPopup.numberOfItems - 1)
        }
        statusLabel.stringValue = " "
    }

    private func currentConfig() -> AIConfig? {
        let key = activeField.stringValue.trimmingCharacters(in: .whitespaces)
        guard !key.isEmpty else { return nil }
        let base = urlField.stringValue.trimmingCharacters(in: .whitespaces)
        let model = modelPopup.titleOfSelectedItem ?? "deepseek-chat"
        return AIConfig(
            apiKey: key,
            model: model,
            baseURL: base.isEmpty ? "https://api.deepseek.com" : base
        )
    }

    @objc private func toggleKeyVisibility(_ sender: NSButton) {
        isKeyVisible.toggle()
        if isKeyVisible {
            visibleField.stringValue = secureField.stringValue
            secureField.isHidden = true
            visibleField.isHidden = false
        } else {
            secureField.stringValue = visibleField.stringValue
            visibleField.isHidden = true
            secureField.isHidden = false
        }
        sender.image = isKeyVisible
            ? NSImage(systemSymbolName: "eye.slash", accessibilityDescription: "隐藏 Key")
            : NSImage(systemSymbolName: "eye", accessibilityDescription: "显示 Key")
    }

    private var activeField: NSTextField {
        isKeyVisible ? visibleField : secureField
    }

    @objc private func testConnection(_ sender: Any?) {
        guard let config = currentConfig() else {
            statusLabel.stringValue = "请先填写 API Key"
            return
        }
        statusLabel.stringValue = "测试中…"
        let client = DeepSeekClient(config: config)
        Task {
            do {
                _ = try await client.chat("你好")
                DispatchQueue.main.async { [weak self] in
                    self?.statusLabel.stringValue = "连接成功 ✓"
                }
            } catch {
                let detail = (error as NSError).localizedDescription
                DispatchQueue.main.async { [weak self] in
                    self?.statusLabel.stringValue = "连接失败：\(detail)"
                }
            }
        }
    }

    @objc private func save(_ sender: Any?) {
        guard let config = currentConfig() else {
            statusLabel.stringValue = "请先填写 API Key"
            return
        }
        ConfigStore.save(config)
        statusLabel.stringValue = "已保存 ✓"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            self?.window.close()
        }
    }

    // 调试：导出窗口内容
    func captureTo(_ path: String) {
        guard let content = window.contentView else { print("capture: no contentView"); return }
        content.displayIfNeeded()
        guard let rep = content.bitmapImageRepForCachingDisplay(in: content.bounds) else {
            print("capture: no rep")
            return
        }
        content.cacheDisplay(in: content.bounds, to: rep)
        guard let data = rep.representation(using: .png, properties: [:]) else {
            print("capture: no data")
            return
        }
        try? data.write(to: URL(fileURLWithPath: path))
        print("capture: wrote \(path)")
    }
}

// MARK: - 右键菜单（Mac 原生样式）
final class MenuActions: NSObject, NSMenuDelegate {
    private let behavior: PetBehavior
    private let petWindow: NSWindow
    private let chatController: ChatWindowController
    private let settingsController: SettingsWindowController

    private var pauseItem: NSMenuItem?
    private var bubbleWindow: NSWindow?
    private var bubbleContainer: NSView?
    private var bubbleLabel: NSTextField?
    private var bubbleTimer: Timer?

    init(behavior: PetBehavior, petWindow: NSWindow, chatController: ChatWindowController, settingsController: SettingsWindowController) {
        self.behavior = behavior
        self.petWindow = petWindow
        self.chatController = chatController
        self.settingsController = settingsController
    }

    func buildMenu() -> NSMenu {
        let menu = NSMenu()

        let chat = NSMenuItem(title: "聊天", action: #selector(openChat(_:)), keyEquivalent: "")
        chat.target = self
        menu.addItem(chat)

        let config = NSMenuItem(title: "设置", action: #selector(openSettings(_:)), keyEquivalent: "")
        config.target = self
        menu.addItem(config)

        let sayHi = NSMenuItem(title: "打招呼", action: #selector(sayHi(_:)), keyEquivalent: "")
        sayHi.target = self
        menu.addItem(sayHi)

        let pause = NSMenuItem(title: "暂停", action: #selector(togglePause(_:)), keyEquivalent: "")
        pause.target = self
        pauseItem = pause
        menu.addItem(pause)

        menu.addItem(NSMenuItem.separator())

        let quit = NSMenuItem(title: "退出", action: #selector(quit(_:)), keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)

        menu.delegate = self
        return menu
    }

    @objc private func sayHi(_ sender: Any?) {
        showBubble("你好呀")
    }

    @objc private func openChat(_ sender: Any?) {
        chatController.show()
    }

    @objc private func openSettings(_ sender: Any?) {
        settingsController.show()
    }

    // 双击触发：猫说“喵”，并自动发到聊天窗口让 AI 回复
    func triggerAutoDialogue() {
        showBubble("喵")
        chatController.show()
        chatController.autoSend("喵")
    }

    func debugShowChatAndCapture() {
        chatController.show()
        if ProcessInfo.processInfo.environment["PET_DEBUG_SEND"] != nil {
            chatController.debugAutoSend("你好呀")
        } else {
            chatController.seedDebugMessages()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            self?.chatController.captureTo("/tmp/pet_chat_check.png")
        }
    }

    @objc private func togglePause(_ sender: Any?) {
        behavior.togglePause()
        updatePauseTitle()
    }

    @objc private func quit(_ sender: Any?) {
        NSApp.terminate(nil)
    }

    func menuNeedsUpdate(_ menu: NSMenu) {
        updatePauseTitle()
    }

    private func updatePauseTitle() {
        pauseItem?.title = behavior.isPaused ? "继续" : "暂停"
    }

    // MARK: 打招呼气泡
    private func showBubble(_ text: String) {
        if bubbleWindow == nil {
            buildBubbleWindow()
        }
        guard let bubble = bubbleWindow,
              let container = bubbleContainer,
              let label = bubbleLabel else { return }

        label.stringValue = text
        label.sizeToFit()

        let padding: CGFloat = 12
        let textSize = label.frame.size
        let size = NSSize(width: textSize.width + padding * 2, height: textSize.height + padding * 2)

        bubble.setContentSize(size)
        container.frame = NSRect(origin: .zero, size: size)
        label.frame = NSRect(x: padding, y: padding, width: textSize.width, height: textSize.height)

        // 放在宠物旁边：优先右侧
        let petFrame = petWindow.frame
        var origin = NSPoint(x: petFrame.maxX + 10, y: petFrame.midY - size.height / 2)
        if let screen = petWindow.screen ?? NSScreen.main {
            let visible = screen.visibleFrame
            if origin.x + size.width > visible.maxX {
                origin.x = petFrame.minX - size.width - 10
            }
            origin.y = max(origin.y, visible.minY)
            if origin.y + size.height > visible.maxY {
                origin.y = visible.maxY - size.height
            }
        }
        bubble.setFrameOrigin(origin)
        bubble.orderFrontRegardless()

        bubbleTimer?.invalidate()
        bubbleTimer = Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { _ in
            bubble.orderOut(nil)
        }
        RunLoop.main.add(bubbleTimer!, forMode: .common)
    }

    private func buildBubbleWindow() {
        let label = NSTextField(labelWithString: "你好呀")
        label.font = .systemFont(ofSize: 14)
        label.alignment = .center
        label.textColor = .labelColor
        label.sizeToFit()

        let padding: CGFloat = 12
        let size = NSSize(width: label.frame.width + padding * 2, height: label.frame.height + padding * 2)

        let bubble = NSWindow(
            contentRect: NSRect(origin: .zero, size: size),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        bubble.backgroundColor = .clear
        bubble.isOpaque = false
        bubble.hasShadow = true
        bubble.level = .floating
        bubble.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        bubble.ignoresMouseEvents = true
        bubble.isReleasedWhenClosed = false

        let container = NSView(frame: NSRect(origin: .zero, size: size))
        container.wantsLayer = true
        container.layer?.backgroundColor = NSColor.windowBackgroundColor.cgColor
        container.layer?.cornerRadius = 10
        label.frame = NSRect(x: padding, y: padding, width: label.frame.width, height: label.frame.height)
        container.addSubview(label)
        bubble.contentView = container

        bubbleLabel = label
        bubbleContainer = container
        bubbleWindow = bubble
    }
}

// MARK: - 一只桌宠（窗口 + 视图 + 行为 + 菜单）
final class PetRig {
    let window: NSWindow
    let imageView: DraggableImageView
    let behavior: PetBehavior
    let menuActions: MenuActions

    init(window: NSWindow, imageView: DraggableImageView, behavior: PetBehavior, menuActions: MenuActions) {
        self.window = window
        self.imageView = imageView
        self.behavior = behavior
        self.menuActions = menuActions
    }
}

func makePet(idleFrames: [NSImage], walkRight: [NSImage], walkLeft: [NSImage],
             disableWalk: Bool, origin: NSPoint,
             chatController: ChatWindowController, settingsController: SettingsWindowController) -> PetRig {
    guard let firstFrame = idleFrames.first else { fatalError("没有动作帧") }
    let rep = firstFrame.representations.first as? NSBitmapImageRep
    let pixelW = CGFloat(rep?.pixelsWide ?? Int(firstFrame.size.width))
    let pixelH = CGFloat(rep?.pixelsHigh ?? Int(firstFrame.size.height))
    let scale = NSScreen.main?.backingScaleFactor ?? 1
    let size = NSSize(width: pixelW / scale, height: pixelH / scale)

    let win = NSWindow(
        contentRect: NSRect(origin: .zero, size: size),
        styleMask: [.borderless],
        backing: .buffered,
        defer: false
    )
    win.backgroundColor = .clear
    win.isOpaque = false
    win.hasShadow = false
    win.level = .floating
    win.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
    win.isReleasedWhenClosed = false
    win.ignoresMouseEvents = true

    let iv = DraggableImageView(frame: NSRect(origin: .zero, size: size))
    iv.image = firstFrame
    iv.imageScaling = .scaleAxesIndependently
    iv.wantsLayer = true
    if let rep = rep {
        iv.setBodyMask(rep)
    }
    win.contentView = iv
    win.setFrameOrigin(origin)

    let behavior = PetBehavior(
        window: win, imageView: iv,
        idleFrames: idleFrames, walkRightFrames: walkRight, walkLeftFrames: walkLeft,
        homeOrigin: origin, disableWalk: disableWalk
    )
    let menu = MenuActions(
        behavior: behavior, petWindow: win,
        chatController: chatController, settingsController: settingsController
    )
    iv.menu = menu.buildMenu()
    iv.onDragEnd = { behavior.handleDropped() }
    behavior.start()
    win.orderFrontRegardless()

    return PetRig(window: win, imageView: iv, behavior: behavior, menuActions: menu)
}

// 共用聊天与设置
let chatController = ChatWindowController()
let settingsController = SettingsWindowController()

func displaySize(_ img: NSImage) -> NSSize {
    let rep = img.representations.first as? NSBitmapImageRep
    let w = CGFloat(rep?.pixelsWide ?? Int(img.size.width))
    let h = CGFloat(rep?.pixelsHigh ?? Int(img.size.height))
    let scale = NSScreen.main?.backingScaleFactor ?? 1
    return NSSize(width: w / scale, height: h / scale)
}

func centerOrigin(_ size: NSSize) -> NSPoint {
    guard let screen = NSScreen.main else { return .zero }
    let v = screen.visibleFrame
    return NSPoint(x: v.midX - size.width / 2, y: v.midY - size.height / 2)
}

// 该 App 实例显示哪只宠物（由 Info.plist 的 PETFLAVOR 决定；无则默认猫）
let flavor = (Bundle.main.object(forInfoDictionaryKey: "PETFLAVOR") as? String) ?? "cat"

let rig: PetRig
if flavor == "dino" {
    // 小恐龙（可自动走动）
    rig = makePet(
        idleFrames: dinoIdle, walkRight: dinoWalkRight, walkLeft: dinoWalkLeft,
        disableWalk: false, origin: centerOrigin(displaySize(dinoFirst)),
        chatController: chatController, settingsController: settingsController
    )
} else {
    // 猫咪（原地动作）
    rig = makePet(
        idleFrames: catIdle, walkRight: catWalkRight, walkLeft: catWalkLeft,
        disableWalk: true, origin: centerOrigin(displaySize(catFirst)),
        chatController: chatController, settingsController: settingsController
    )
}

// 只有芋圆（猫）启用“双击自动对话”
if flavor == "cat" {
    rig.imageView.onDoubleClick = { rig.menuActions.triggerAutoDialogue() }
}

app.activate(ignoringOtherApps: true)

// 确保本地配置文件存在（模板）
ConfigStore.ensureExists()

if ProcessInfo.processInfo.environment["PET_DEBUG_CHAT"] != nil {
    rig.menuActions.debugShowChatAndCapture()
}

if ProcessInfo.processInfo.environment["PET_DEBUG_SETTINGS"] != nil {
    settingsController.show()
    RunLoop.main.run(until: Date().addingTimeInterval(0.6))
    settingsController.captureTo("/tmp/pet_settings_check.png")
}

app.run()
